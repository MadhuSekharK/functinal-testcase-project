package org.com.test.functional.web;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LoginPageTestCase {

	public static WebDriver driver;

	@Test
	public void signInTest() throws IOException {
		getWebDriver();
	}

	static Properties props = null;
	static FileInputStream in = null;

	public static void loadProperties() throws IOException {
		in = new FileInputStream("./config.properties");
		props = new Properties();
		props.load(in);
	}

	public static String getUserName() throws IOException {
		if (props == null)
			loadProperties();
		return props.getProperty("my_username");
	}

	public static String getPassword() throws IOException {
		return props.getProperty("my_password");
	}

	public WebDriver getWebDriver() throws IOException {
		loadProperties();
		System.setProperty("webdriver.chrome.driver", "D://BrowserDriver/chromedriver.exe");
		driver = new ChromeDriver();

		// Launching and Authenticate Application.

		driver.get("https://candidatex:qa-is-cool@qa-task.backbasecloud.com");

		driver.manage().window().maximize();
		// Login

		driver.findElement(By.linkText("Sign in")).click();

		// Enter Credentials

		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys(getUserName());

		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(getPassword());
		in.close();

		// Click on Sign In

		driver.findElement(By.xpath("//*[@class='btn btn-lg btn-primary pull-xs-right']")).click();
		return driver;
	}

}
