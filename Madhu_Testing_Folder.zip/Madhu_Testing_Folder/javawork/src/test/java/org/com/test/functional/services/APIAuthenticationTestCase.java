package org.com.test.functional.services;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import io.restassured.RestAssured;

import io.restassured.http.ContentType;

import io.restassured.response.Response;

import org.com.test.functional.web.LoginPageTestCase;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.testng.annotations.BeforeClass;

//import org.apache.http.HttpStatus;
//import org.junit.jupiter.api.*;
//import org.junit.Before;

import org.testng.annotations.Test;

public class APIAuthenticationTestCase {

	// public static void main(String args[]);
	public static void testValidLoginCredentials() {

	}

//	RestAssured.baseURI = "https://qa-task.backbasecloud.com";
	@BeforeClass
	public static void setup() {
		RestAssured.baseURI = "https://qa-task.backbasecloud.com";
	}

	@Test
	public void postRequest() throws IOException {
		String myUsername = LoginPageTestCase.getUserName();
		String requestBody = "{\"user\":{\"email\":\"" + myUsername + "\",\"password\":\"password531\"}}";
		JSONObject jsonObject = new JSONObject(requestBody);
		Response response = given().auth().preemptive().basic("candidatex", "qa-is-cool")
				.header("Accept", ContentType.JSON.getAcceptHeader()).contentType(ContentType.JSON).body(requestBody)
				.when().post("/api/users/login").then().extract().response();

		System.out.println("my response-->" + response.asPrettyString());
		JSONObject jsonObject1 = new JSONObject(response.asPrettyString());
		JSONObject jsonObject2 = new JSONObject(jsonObject1.get("user").toString());
		String token = jsonObject2.getString("token");
		String username = jsonObject2.getString("username");
		String email = jsonObject2.getString("email");
		Assertions.assertNotNull(token);
		Assertions.assertNotNull(username);
		Assertions.assertNotNull(email);
		Assertions.assertEquals(200, response.statusCode());

	}

}
