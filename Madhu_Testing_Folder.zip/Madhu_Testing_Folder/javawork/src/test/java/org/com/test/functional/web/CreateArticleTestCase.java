package org.com.test.functional.web;

import java.io.IOException;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CreateArticleTestCase {

	@Test
	public void createArticleTest() throws InterruptedException, IOException {
		WebDriver driver = LoginPageTestCase.driver;

		// Click on New Article
		driver.findElement(By.xpath("//nav[@class='navbar navbar-light']//a[@href ='/editor']")).click();

		// Enter Article Name

		driver.findElement(By.xpath("//fieldset[@class='form-group']//input[@placeholder='Article Title']"))
				.sendKeys("MadhuArticle");
		// Write Article
		String username = "PerformanceTesting" + new Random().nextInt(1000);

		driver.findElement(
				By.xpath("//fieldset[@class='form-group']/textarea[@placeholder='Write your article (in markdown)']"))
				.sendKeys(username);

		driver.findElement(By.xpath("//*[@class='btn btn-lg pull-xs-right btn-primary']")).click();
		
		Thread.sleep(3000);
		Assert.assertTrue(driver.getPageSource().contains(username), "New Article Creation Failed !");

		// Delete Article

		Thread.sleep(6000);

		driver.findElement(By.xpath("//i[@class='ion-trash-a']")).click();
// Close Driver
		driver.close();

	}

}
