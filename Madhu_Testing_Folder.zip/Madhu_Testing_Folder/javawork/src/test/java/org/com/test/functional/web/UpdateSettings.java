package org.com.test.functional.web;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;

//import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class UpdateSettings {

	@Test
	public void testUpdateSettings() throws InterruptedException, IOException {

		WebDriver driver = LoginPageTestCase.driver;

		// Update Settings

		Thread.sleep(3000);

		String passwordset = "password" + new Random().nextInt(1000);

		driver.findElement(By.xpath("//nav[@class='navbar navbar-light']//a[@href ='/settings']")).click();

		Thread.sleep(2000);
//		List<WebElement> formElements = driver.findElements(By.tagName("form"));

//		WebElement textArea = formElements.get(0).findElements(By.tagName("fieldset")).get(2);

		driver.findElement(By.xpath("//form//fieldset[3]/textarea")).sendKeys("testing going on...");

		driver.findElement(By.xpath("//form//fieldset[5]/input")).sendKeys(passwordset);

		writeValueInPropertyFile(passwordset);

		driver.findElement(By.xpath("//button[@type='submit']")).click();

	}

	public void writeValueInPropertyFile(String updatedPwd) {
		try {
//			OutputStream output = new FileOutputStream("./config.properties");
			FileOutputStream out = new FileOutputStream("./config.properties");
			Properties prop = new Properties();
			prop.setProperty("my_password", updatedPwd);
			prop.setProperty("my_username", "john5@john5.john5");
			prop.store(out, null);
			out.close();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

}
