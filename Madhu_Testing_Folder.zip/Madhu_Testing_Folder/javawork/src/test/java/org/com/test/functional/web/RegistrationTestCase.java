package org.com.test.functional.web;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class RegistrationTestCase {

	@Test
	public void registerTest() {
		System.setProperty("webdriver.chrome.driver", "D://BrowserDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//Authentication
		
		driver.get("https://candidatex:qa-is-cool@qa-task.backbasecloud.com");
       
		//Click on Sign up
		
		driver.findElement(By.linkText("Sign up")).click();
		
		//Enter Required Details

		driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("AmitabhBachan5");
		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("Amitabh5@Amitabh5.Amitabh5");

		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("amitabhamitabh");

		driver.findElement(By.xpath("//*[@class='btn btn-lg btn-primary pull-xs-right']")).click();
		
		// Close Driver
				driver.close();
	}
}
