package org.com.test.functional.services;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;

import io.restassured.http.ContentType;

import io.restassured.response.Response;

import org.junit.jupiter.api.Assertions;

import org.testng.annotations.BeforeClass;


import org.testng.annotations.Test;


public class APIGetTagsTest {
	
	public static void GetAPI() {

	}
	
	@BeforeClass
    public static void setup() {
        RestAssured.baseURI = "https://qa-task.backbasecloud.com";
    }

    @Test
    public void getRequest() {
        Response response = given().auth().preemptive().basic("candidatex", "qa-is-cool")
				.header("Accept", ContentType.JSON.getAcceptHeader()).contentType(ContentType.JSON)
                
                .when()
                .get("/api/tags")
                .then()
                .extract().response();
       Assertions.assertEquals(200, response.statusCode());
        System.out.println("my response-->" + response.asPrettyString());
		
	}
	
}


